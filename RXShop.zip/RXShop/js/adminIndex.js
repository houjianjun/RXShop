function initializeJS() {
	//工具提示
	jQuery('.tooltips').tooltip();
	//弹出框
	jQuery('.popovers').popover();
	//需引入nicescroll插件
	//html添加背景与滚动
	jQuery("html").niceScroll({
		styler: "fb",
		cursorcolor: "#007AFF",
		cursorwidth: '6',
		cursorborderradius: '10px',
		background: '#F7F7F7',
		cursorborder: '',
		zindex: '1000'
	});
	
	//侧边栏
	jQuery("#sidebar").niceScroll({
		styler: "fb",
		cursorcolor: "#007AFF",
		cursorwidth: '3',
		cursorborderradius: '10px',
		background: '#F7F7F7',
		cursorborder: ''
	});
	
	//滚动面板
	jQuery(".scroll-panel").niceScroll({
		styler: "fb",
		cursorcolor: "#007AFF",
		cursorwidth: '3',
		cursorborderradius: '10px',
		background: '#F7F7F7',
		cursorborder: ''
	});
	
	//侧边栏下拉---上下滑动
	jQuery('#sidebar .sub-menu > a').click(function() {
		var last = jQuery('.sub-menu.open', jQuery('#sidebar'));
		jQuery('.menu-arrow').removeClass('glyphicon-chevron-right');
		 jQuery('.menu-arrow').removeClass('glyphicon-chevron-down');
		//滑动效果
		jQuery('.sub', last).slideUp(200);
		var sub = jQuery(this).next();
		//如果隐藏
		if(sub.is(":visible")) {
			//添加样式
			jQuery('.menu-arrow').addClass('glyphicon-chevron-right');
			sub.slideUp(200);
		} else {
			jQuery('.menu-arrow').addClass('glyphicon-chevron-down');
			sub.slideDown(200);
		}
		var o = (jQuery(this).offset());
		diff = 200 - o.top;
		if(diff > 0)
			jQuery("#sidebar").scrollTo("-=" + Math.abs(diff), 500);
		else
			jQuery("#sidebar").scrollTo("+=" + Math.abs(diff), 500);
	});
	//菜单切换--根据不同的分辨率
	jQuery(function() {
		function responsiveView() {
			var wSize = jQuery(window).width();
			if(wSize <= 768) {
				jQuery('#container').addClass('sidebar-closed');
				jQuery('#sidebar > ul').hide();
			}

			if(wSize > 768) {
				jQuery('#container').removeClass('sidebar-closed');
				jQuery('#sidebar > ul').show();
			}
		}
		jQuery(window).on('load', responsiveView);
		jQuery(window).on('resize', responsiveView);
	});
	//切换导航
	jQuery('.toggle-nav').click(function() {
		if(jQuery('#sidebar > ul').is(":visible") === true) {
			jQuery('#main-content').css({
				'margin-left': '0px'
			});
			jQuery('#sidebar').css({
				'margin-left': '-180px'
			});
			jQuery('#sidebar > ul').hide();
			jQuery("#container").addClass("sidebar-closed");
		} else {
			jQuery('#main-content').css({
				'margin-left': '180px'
			});
			jQuery('#sidebar > ul').show();
			jQuery('#sidebar').css({
				'margin-left': '0'
			});
			jQuery("#container").removeClass("sidebar-closed");
		}
	});
	
	

}
//加载JS
jQuery(document).ready(function() {		
	initializeJS();
});